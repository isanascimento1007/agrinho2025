let gameState = "campo";
let truck;
let items = [];
let collected = 0;
let totalToCollect = 6;
let backgroundColor;

let farmItems = ["🍎", "🥕", "🌽", "🍓", "🍉", "🥔"];
let truckEmoji = "🚛";

function setup() {
  createCanvas(700, 400);
  textAlign(CENTER, CENTER);
  textSize(32);
  truck = new Truck();
}

function draw() {
  if (gameState === "campo") {
    background(120, 200, 120);
    textSize(20);
    fill(0);
    text("Recolha 6 produtos agrícolas", width / 2, 30);
    text(`Coletados: ${collected} / ${totalToCollect}`, width / 2, 60);

    truck.update();
    truck.show();

    if (frameCount % 60 === 0) {
      items.push(new FarmItem());
    }

    for (let i = items.length - 1; i >= 0; i--) {
      items[i].update();
      items[i].show();

      if (items[i].hits(truck)) {
        collected++;
        items.splice(i, 1);
        if (collected >= totalToCollect) {
          gameState = "viagem";
        }
      } else if (items[i].offscreen()) {
        items.splice(i, 1);
      }
    }
  } else if (gameState === "viagem") {
    runToCity();
  } else if (gameState === "cidade") {
    background(180);
    textSize(28);
    fill(0);
    text("Você chegou à cidade com os produtos! 🏙️", width / 2, height / 2);
  }
}

// Caminhão controlado pelo jogador
class Truck {
  constructor() {
    this.x = width / 2;
    this.y = height - 40;
    this.size = 32;
  }

  update() {
    if (keyIsDown(LEFT_ARROW)) this.x -= 5;
    if (keyIsDown(RIGHT_ARROW)) this.x += 5;
    this.x = constrain(this.x, 0, width - this.size);
  }

  show() {
    textSize(this.size);
    text(truckEmoji, this.x, this.y);
  }

  getBounds() {
    return { x: this.x, y: this.y, w: 32, h: 32 };
  }
}

// Itens agrícolas que caem do céu
class FarmItem {
  constructor() {
    this.x = random(width);
    this.y = 0;
    this.speed = 3;
    this.size = 28;
    this.emoji = random(farmItems);
  }

  update() {
    this.y += this.speed;
  }

  show() {
    textSize(this.size);
    text(this.emoji, this.x, this.y);
  }

  hits(truck) {
    let t = truck.getBounds();
    return collideRectCircle(t.x, t.y, t.w, t.h, this.x, this.y, 32);
  }

  offscreen() {
    return this.y > height;
  }
}

// Caminhão indo pra cidade (fase final)
function runToCity() {
  background(220);
  fill(0);
  textSize(22);
  text("Viajando para a cidade... Pressione → para andar", width / 2, 40);

  truck.show();

  if (keyIsDown(RIGHT_ARROW)) {
    truck.x += 4;
  }

  if (truck.x > width) {
    gameState = "cidade";
  }
}
